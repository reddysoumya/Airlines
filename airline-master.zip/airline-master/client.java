package com.ab.ui;

import java.util.Scanner;

import com.ab.bean.AirBean;
import com.zb.service.AirServiceImpl;
import com.zb.service.IAirService;

public class client {
	static Scanner sc=null;
	static IAirService service=null;
	static AirBean air=null;
	public static int flightId;
	static int seats;
	public static int bookId;
public static void main(String[] args) throws Exception {
	System.out.println("Airline Booking system");
	System.out.println("----------------");
	System.out.println("1.Add flight details");
	System.out.println("2.Book flight");
	System.out.println("3.Exit");
	sc=new Scanner(System.in);
	System.out.println("Enter your choice");
	int ch=sc.nextInt();
	switch(ch) {
	case 1:
		System.out.println("Enter flight id");
		int fid=sc.nextInt();
		System.out.println("Enter flight name");
		String fname=sc.next();
		System.out.println("Enter arrival point");
		String apoint=sc.next();
		System.out.println("Enter departure point");
		String dpoint=sc.next();
		System.out.println("Enter seats in flight");
		int fseats=sc.nextInt();
		air=new AirBean(fid, fname, apoint, dpoint, fseats );
		int status=0;
		status=addDetails(air);
		if(status>0) {
			System.out.println(status+"data inserted");
		}
		else {
			System.out.println("no data inserted");
		}
		
		
		
		break;
		
	case 2:
		System.out.println("Enter flight id");
		int flightId=sc.nextInt();
			if(service.checkFlight(flightId)) {
		System.out.println("Enter no of seats to be booked:");
		 seats=sc.nextInt();
		air=retriveById(flightId);
		 int updatedseats=air.getAvailableSeats()-seats;
		 air.setAvailableSeats(updatedseats);
		 client.updateDetails(air);
		if(air!=null) {
			System.out.println("flight found");
			System.out.println("details are:"+air);
			System.out.println("you have booked flight with"+air.getFlightName()+"and your booking id is"+"   "  +bookId);
		}
		else {
			System.out.println("no flights available");
		}
				}
		else {
			System.out.println("Enter valid flight Id");
		}
		break;
		
	case 3:
		System.exit(0);
		break;
	}

}
public static  int  addDetails(AirBean air) throws Exception {
	service=new AirServiceImpl();
	return service.addFlightDetails(air);
}
public static AirBean retriveById(int flightId) throws Exception {
	service=new AirServiceImpl();
	return service.getflightById(flightId);
}


public static int updateDetails(AirBean air) throws Exception
{
	
	service=new AirServiceImpl();
	
	return service.updateDetails(air);
}
	public static void getBook(int bookingId) {
	bookId=bookingId;
}
}
