package com.ab.dao;

import com.ab.bean.AirBean;

public interface IAirServiceDao {
	public abstract int addFlightDetails(AirBean air) throws Exception;
	public abstract AirBean getflightById(int flightId) throws Exception;
	public abstract int updateDetails(AirBean air) throws Exception;
	public abstract boolean checkFlight(int flightId) throws Exception;
}
