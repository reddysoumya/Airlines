package com.ab.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import com.ab.bean.AirBean;
import com.ab.util.DbUtil;

public class AirServiceDaoImpl implements IAirServiceDao{
	Connection conn=null;
	AirBean air=null;
	int bookingId;
	@Override
	public int addFlightDetails(AirBean air) throws Exception {
		conn=DbUtil.getConnection();
		PreparedStatement prepare=conn.prepareStatement(IQueryMapper.insert_query);
		prepare.setInt(1, air.getFlightId());
		prepare.setString(2, air.getFlightName());
		prepare.setString(3, air.getArrivalPoint());
		prepare.setString(4, air.getDepPoint());
		prepare.setInt(5, air.getAvailableSeats());
		int status=prepare.executeUpdate();
		return status;
		
	}

	@Override
	public AirBean getflightById(int flightId) throws Exception {
		conn=DbUtil.getConnection();
		PreparedStatement prepare=conn.prepareStatement(IQueryMapper.retrive_query);
		prepare.setInt(1, flightId);
		ResultSet rs=prepare.executeQuery();
		while(rs.next()) {
			
			System.out.println(rs.getInt(1));
			System.out.println(rs.getString(2));
			System.out.println(rs.getString(3));
			System.out.println(rs.getString(4));
			System.out.println(rs.getInt(6));
		
			
			
			air=new AirBean(rs.getInt(1), rs.getString(2), rs.getString(3), rs.getString(4), rs.getInt(6));
		}
		return air;
	}

	@Override
	public int updateDetails(AirBean air) throws Exception 
	{
		conn=DbUtil.getConnection();
		PreparedStatement prepare=conn.prepareStatement(IQueryMapper.update_query);
		
		prepare.setInt(1, air.getAvailableSeats());
		prepare.setInt(2, air.getFlightId());
		int rs=prepare.executeUpdate();
		int fid=air.getFlightId();
		PreparedStatement prepare1=conn.prepareStatement(IQueryMapper.get_booking);
		prepare1.setInt(1, fid);
		ResultSet rs1=prepare1.executeQuery();
		rs1.next();
		bookingId=rs1.getInt(1);
		client cli=new client();
		cli.getBook(bookingId);
		
		return 0;
	}
	public boolean checkFlight(int flightId) throws Exception  {
		try {
			conn=DbUtil.getConnection();
			PreparedStatement prepare=conn.prepareStatement(IQueryMapper.flight_check);
			prepare.setInt(1, flightId);
			ResultSet rs=prepare.executeQuery();
			if(rs.next()) {
				return true;
			}
			return false;
		} catch (SQLException e) {
			System.out.println("please enter valid flight id");
			e.printStackTrace();
		}
		return false;

}
