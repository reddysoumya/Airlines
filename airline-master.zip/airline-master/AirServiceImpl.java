package com.zb.service;

import com.ab.bean.AirBean;
import com.ab.dao.AirServiceDaoImpl;
import com.ab.dao.IAirServiceDao;

public class AirServiceImpl implements IAirService{
	IAirServiceDao dao=null;

	@Override
	public int addFlightDetails(AirBean air) throws Exception {
		dao=new AirServiceDaoImpl();
		return dao.addFlightDetails(air);
	}

	@Override
	public AirBean getflightById(int flightId) throws Exception {
		dao=new AirServiceDaoImpl();
		return dao.getflightById(flightId);
	}

	@Override
	public int updateDetails(AirBean air) throws Exception {
		dao=new AirServiceDaoImpl();
		return dao.updateDetails(air);
	}
	public boolean checkFlight(int flightId) throws Exception {
		dao=new AirServiceDaoImpl();
		return dao.checkFlight(flightId);
	}

}
