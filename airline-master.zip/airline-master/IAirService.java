package com.zb.service;

import com.ab.bean.AirBean;

public interface IAirService {
public abstract int addFlightDetails(AirBean air) throws Exception;
public abstract AirBean getflightById(int flightId) throws Exception;
public abstract int updateDetails(AirBean air) throws Exception;
  public abstract boolean checkFlight(int flightId) throws Exception;
}
